# Version 3.3.0
- Added a hotkey combo. Holding shift while changing quantity will round it to the nearest multiple of 5.

# Version 3.2.0
- Added the ability to see the price per unit when NPC's send you an offer

# Version 3.1.0
- Mono version is now available!

# Version 3.0.0
- Fixed bug that caused offer information fields to be unreadable
- Added a configuration file that controls which fields are enabled for the user
- Added filter buttons for switching between favorites, listed, and discovered products

# Version 2.0.0
- Field for tracking the intial offer price from the customer
- Field for tracking the customer's spend limit
- Field for displaying the success chance that changes color depening on the probablity value
- Added a button to the product selector to enable toggling between listed products and all products

# Version 1.1.0
- Fixed bug preventing the Counter-Offer Pop-up to not display
- Updated mod to work with the new ProductSelector UI

# Version 1.0.0
- Product Selector only displays products that are listed for sale
- Offer price updates when changing product and quantity.